#!/bin/sh
# VMWare modules source patch "installer" script
# krellan
if [ $(whoami) != "root" ]
then
  echo "You must run this script as root."
  exit 1
fi

# Change these if desired
VMMODDIR="/usr/lib/vmware/modules"
PATCHFILE="vmware-server.2.0.1_x64-modules-2.6.30.4-fix.patch"

# Take inventory
OLDDIR=`pwd`
MODSOURCEDIR="${VMMODDIR}/source"
PATCHPATH="${OLDDIR}/${PATCHFILE}"
if [ ! -r "$PATCHPATH" ]; then
	echo "Sorry, patch file $PATCHPATH not found"
	exit 1
fi
cd "$MODSOURCEDIR"
TARS=`find . -maxdepth 1 -name '*.tar'`
if [ ! "$TARS" ]; then
	echo "Sorry, no tar files found in $MODSOURCEDIR"
	exit 1
fi
BASES=""
for TARFILE in $TARS
do
	BASE=`basename "$TARFILE" | rev | cut -c5- | rev`
	BASES="$BASES $BASE"
	echo "Found tar file for $BASE module"
done

# Back up existing tarballs if not already done
BACKDIR="${VMMODDIR}/source-backup"
echo "Using patch file: $PATCHPATH"
echo "Using module directory: $MODSOURCEDIR"
echo "Using backup directory: $BACKDIR"
mkdir -p "$BACKDIR"
for TARFILE in $TARS
do
	BACKFILE="${BACKDIR}/${TARFILE}"
	if [ ! -r "$BACKFILE" ]; then
		echo "Backing up $TARFILE to $BACKFILE"
		cp -a -f "$TARFILE" "$BACKFILE"
		if [ ! -r "$BACKFILE" ]; then
			echo "Sorry, unable to write backup file"
			echo "Did you remember to become root before running this script?"
			exit 1
		fi
	fi
done

# Untar all
for BASE in $BASES
do
	TARFILE="${BASE}.tar"
	MODDIR="${BASE}-only"
	echo "Untarring $TARFILE"
	tar -xf "$TARFILE"
	if [ ! -d "$MODDIR" ]; then
		echo "Sorry, $TARFILE tarball failed to extract the directory $MODDIR"
		exit 1
	fi
done

# Test patch first, so we can exit cleanly if any error
echo "Testing patch"
patch --dry-run -N -p1 < "$PATCHPATH"
RESULT=$?
if [ "0" != "$RESULT" ]; then
	echo "Sorry, problem with the patch, I can't apply it"
	exit 1
fi

# Apply patch
echo "Applying patch!"
patch -N -p1 < "$PATCHPATH"
RESULT=$?
if [ "0" != "$RESULT" ]; then
	echo "Sorry, problem with the patch while in the middle of applying it"
	echo "You must restore from this backup directory:"
	echo "$BACKDIR"
	exit 1
fi

# Repack tarballs immediately after applying patch, into temporary files
for BASE in $BASES
do
	TEMPFILE="${BASE}-temp.tar"
	MODDIR="${BASE}-only"
	echo "Preparing new tar file for $BASE module"
	rm -f "$TEMPFILE"
	tar -cf "$TEMPFILE" "$MODDIR"
done

# Make sure it makes
for BASE in $BASES
do
	# Skip checking vmppuser module because it's badly broken dead code
	if [ "vmppuser" != "$BASE" ]; then
		MODDIR="${BASE}-only"
		cd "$MODDIR"
		echo "Trying to compile $BASE module to see if it works"
		make
		RESULT=$?
		if [ "0" != "$RESULT" ]; then
			echo "Sorry, problem compiling the $BASE module after it was patched"
			echo "You must restore from this backup directory:"
			echo "$BACKDIR"
			exit 1
		fi
		cd "$MODSOURCEDIR"
	fi
done

# It made cleanly, so now replace original tarballs
for BASE in $BASES
do
	TEMPFILE="${BASE}-temp.tar"
	TARFILE="${BASE}.tar"
	echo "Replacing original file $TARFILE with patched file"
	rm -f "$TARFILE"
	mv -f "$TEMPFILE" "$TARFILE"
done

# All appears good, remind user about next step
echo "Done!"
echo
echo "I have changed the files in here:"
echo "$MODSOURCEDIR"
echo
echo "I have placed a backup of the original files in here:"
echo "$BACKDIR"
echo
BINDIR="${VMMODDIR}/binary"
if [ -d "$BINDIR" ]; then
	echo "The original VMware modules directory is still in the way."
	echo "Please move this directory somewhere else, because it confuses VMware:"
	echo "$BINDIR"
	echo
fi
echo "This command should work now, to install the modules:"
echo "vmware-config.pl -d"
exit 0
